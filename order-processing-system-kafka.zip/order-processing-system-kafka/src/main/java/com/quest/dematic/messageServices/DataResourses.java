package com.quest.dematic.messageServices;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/data")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class DataResourses {
	
//	@Inject
//	Producer producer;
//	
//	@POST
//	public Response send(String message) {
//		producer.sendKafkaData(message);
//		System.out.println("Got a message : "+message);
//		return Response.accepted().build();
//	}

}
