package com.quest.dematic.entity;

public enum Unit {
	
	kg, 
	gm
	
}
