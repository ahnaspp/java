package com.quest.dematic.messageServices;

import javax.enterprise.context.ApplicationScoped;

//import org.eclipse.microprofile.reactive.messaging.Incoming;
//import org.jboss.logging.Logger;

@ApplicationScoped
public class Consumer {
	
//	private final Logger logger = Logger.getLogger(Consumer.class);
//	
//	@Incoming("data-input")
//	public void recieve(String message) {
//		logger.infof("Got a message: ", message);
//	}

}
