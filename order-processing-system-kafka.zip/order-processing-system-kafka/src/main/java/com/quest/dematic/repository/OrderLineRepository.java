package com.quest.dematic.repository;

import javax.enterprise.context.ApplicationScoped;


@ApplicationScoped
public class OrderLineRepository {

}
