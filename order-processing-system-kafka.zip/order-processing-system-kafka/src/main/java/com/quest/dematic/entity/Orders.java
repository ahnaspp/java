package com.quest.dematic.entity;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import io.quarkus.hibernate.orm.panache.PanacheEntity;


@Entity
public class Orders extends PanacheEntity {
	
	
	@Enumerated(EnumType.STRING)
	public OrderStatus status;
	
	public LocalDate createdDate;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.EAGER)
	@JoinColumn(name= "orderLines")
	public List<Product> orderLines;

}
