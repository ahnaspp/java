package com.quest.dematic.entity;

import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import io.quarkus.hibernate.orm.panache.PanacheEntity;



@Entity
public class Product {
 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long id;
	
	@Column(unique = true)
	public String productCode;
	
	public Double quantity;
	
	@Enumerated(EnumType.STRING)
	public Unit quantityUnit;
	
	@Enumerated(EnumType.STRING)
	public ProductStatus status;

	@ManyToOne
	@JsonbTransient
	public Orders orderLines;

}
