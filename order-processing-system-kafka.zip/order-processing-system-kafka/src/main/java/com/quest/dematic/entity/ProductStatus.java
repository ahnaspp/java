package com.quest.dematic.entity;

public enum ProductStatus {

	PENDING,
	COMPLETED
	
}
