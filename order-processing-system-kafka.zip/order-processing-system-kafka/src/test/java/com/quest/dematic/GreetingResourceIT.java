package com.quest.dematic;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class GreetingResourceIT extends OrderResourceTest {
    // Execute the same tests but in packaged mode.
}
