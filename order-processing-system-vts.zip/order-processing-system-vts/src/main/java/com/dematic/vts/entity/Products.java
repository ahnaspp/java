package com.dematic.vts.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Entity
public class Products {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private String productCode;
	
	@Column(nullable = false)
	private Double quantity;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private Unit quantityUnit;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private Status productStatus;

	@ManyToOne
	private Orders orders;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public Unit getQuantityUnit() {
		return quantityUnit;
	}

	public void setQuantityUnit(Unit quantityUnit) {
		this.quantityUnit = quantityUnit;
	}

	public Status getProductStatus() {
		return productStatus;
	}

	public void setProductStatus(Status productStatus) {
		this.productStatus = productStatus;
	}
	
	

}
