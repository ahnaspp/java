package com.dematic.vts.repository;


import javax.enterprise.context.ApplicationScoped;

import com.dematic.vts.entity.Orders;

import io.quarkus.hibernate.reactive.panache.PanacheRepository;

@ApplicationScoped
public class OrderRepository implements PanacheRepository<Orders>{

}
