package com.dematic.vts.dto;

import java.time.LocalDate;
import java.util.List;

import com.dematic.vts.entity.Status;

import lombok.Data;

@Data
public class OrderDto {
	
	private Long id;
	
	private Status orderStatus;
	
	private LocalDate createdDate;
	
	private List<ProductDto> orderLines;

	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Status getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(Status orderStatus) {
		this.orderStatus = orderStatus;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public List<ProductDto> getOrderLines() {
		return orderLines;
	}

	public void setOrderLines(List<ProductDto> orderLines) {
		this.orderLines = orderLines;
	}
	
	

}
