package com.dematic.vts.service;

import com.dematic.vts.entity.Orders;
import com.dematic.vts.entity.Status;

import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;

public interface OrderService {
	
	Uni<Orders> getById(Long id);
	
	Multi<Orders> getAll();
	
	Multi<Orders> getByStatus(Status status);
	
	Uni<Orders> create(Orders orders);
	
	Uni<Orders> updateStatus(Long id, Status status);
	
	Uni<Boolean> delete(Long id);
	
	
	
	
	

}
