package com.dematic.vts.service;


import java.time.Duration;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.core.Response;

import com.dematic.vts.BaseHttpException;
import com.dematic.vts.entity.Orders;
import com.dematic.vts.entity.Status;
import com.dematic.vts.repository.OrderRepository;

import io.quarkus.hibernate.reactive.panache.common.runtime.ReactiveTransactional;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;

@ApplicationScoped
public class OrderServiceImpl implements OrderService{

	@Inject
	OrderRepository orderRepository;
	
	
	
	@Override
	public Uni<Orders> getById(Long id) {
		return orderRepository.findById(id).replaceIfNullWith(() -> {
			throw new BaseHttpException(Response.Status.NOT_FOUND, "Order with ID = "+ id+" not found");
		});			
	}

	@Override
	public Multi<Orders> getAll() {
		
		return orderRepository.streamAll().ifNoItem().after(Duration.ofMillis(5)).failWith(() -> {
			throw new BaseHttpException(Response.Status.NO_CONTENT,  "Oops Order list is empty");
		});
	}

	@Override
	public Multi<Orders> getByStatus(Status status) {
		return orderRepository.find("SELECT ord FROM Orders ord WHERE ord.orderStatus = ?1", status).stream().ifNoItem()
				.after(Duration.ofMillis(5)).failWith(() -> {
					throw new BaseHttpException(Response.Status.NO_CONTENT,  "Order with Status = "+ status+" not found");
				});
	
	}
	@ReactiveTransactional
	@Override
	public Uni<Orders> create(Orders orders) {
		return orderRepository.persist(orders);
		}

	@ReactiveTransactional
	@Override
	public Uni<Orders> updateStatus(Long id, Status status) {
		return orderRepository.findById(id)
        .replaceIfNullWith(() -> {
            throw new BaseHttpException(Response.Status.NOT_FOUND, "Order with ID = "+ id+" not found");
        })
        .call(	ord -> {ord.setOrderStatus(status);
        		return orderRepository.persistAndFlush(ord);});
	}

	@ReactiveTransactional
	@Override
	public Uni<Boolean> delete(Long id) {
		return orderRepository.deleteById(id);
	}

}
