package com.dematic.vts.mapper;

import java.util.List;
import java.util.stream.Collectors;

import com.dematic.vts.dto.OrderDto;
import com.dematic.vts.dto.ProductDto;
import com.dematic.vts.entity.Orders;


public class OrderDtoMapper implements DataMapper<Orders, OrderDto>{

	@Override
	public OrderDto map(Orders orders) {
		List<ProductDto> orderLines = null;
		if(orders.getOrderLines() != null) {
			orderLines = orders.getOrderLines().stream().map( mapping -> {
				ProductDto productdto = new ProductDto();
				productdto.setId(mapping.getId());
				productdto.setProductCode(mapping.getProductCode());
				productdto.setProductStatus(mapping.getProductStatus());
				productdto.setQuantity(mapping.getQuantity());
				productdto.setQuantityUnit(mapping.getQuantityUnit());
				return productdto;
			}).collect(Collectors.toList());
		}
		
		OrderDto dto = new OrderDto();
		
		dto.setId(orders.id);
		dto.setCreatedDate(orders.getCreatedDate());
		dto.setOrderStatus(orders.getOrderStatus());
		dto.setOrderLines(orderLines);
		
		return dto;
	}

}
