package com.dematic.vts.responder;

import com.dematic.vts.dto.OrderDto;
import com.dematic.vts.entity.Orders;
import com.dematic.vts.mapper.OrderDtoMapper;

import io.smallrye.mutiny.Multi;

public class OrderMultiResponder implements Responder<Multi<Orders>, Multi<OrderDto>>{

	private final OrderDtoMapper orderDtoMapper;
	
	public OrderMultiResponder(OrderDtoMapper orderDtoMapper) {
		this.orderDtoMapper = orderDtoMapper;
	}

	@Override
	public Multi<OrderDto> respond(Multi<Orders> orders) {
		return orders.onItem().transform(orderDtoMapper::map);
	}

	
	
}
