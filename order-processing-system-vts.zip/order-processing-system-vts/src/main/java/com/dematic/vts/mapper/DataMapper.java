package com.dematic.vts.mapper;

@FunctionalInterface
public interface DataMapper<S,D> {
	D map(final S source);

}
