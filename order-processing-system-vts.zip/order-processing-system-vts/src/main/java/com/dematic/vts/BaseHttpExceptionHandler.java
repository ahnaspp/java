package com.dematic.vts;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Provider
public class BaseHttpExceptionHandler implements ExceptionMapper<BaseHttpException>{

	@Override
	public Response toResponse(BaseHttpException e) {
		ErrorData errorData = new ErrorData();
		errorData.setStatus(e.getStatus());
		errorData.setMessage(e.getMessage());
		errorData.setTimeStamp(e.getTimeStamp());
		return Response.status(errorData.getStatus()).entity(errorData).build();
	}

}
