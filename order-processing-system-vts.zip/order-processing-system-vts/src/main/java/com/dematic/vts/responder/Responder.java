package com.dematic.vts.responder;

@FunctionalInterface
public interface Responder<S, D> {
	D respond(final S source);

}
