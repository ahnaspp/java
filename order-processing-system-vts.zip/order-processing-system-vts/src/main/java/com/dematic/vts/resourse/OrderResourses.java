package com.dematic.vts.resourse;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.jboss.resteasy.reactive.RestPath;

import com.dematic.vts.dto.OrderDto;
import com.dematic.vts.entity.Orders;
import com.dematic.vts.entity.Status;
import com.dematic.vts.mapper.OrderDtoMapper;
import com.dematic.vts.responder.OrderMultiResponder;
import com.dematic.vts.responder.OrderUniResponder;
import com.dematic.vts.service.OrderService;

import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;

@Path("/orders")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@ApplicationScoped
public class OrderResourses {
	
	private final OrderDtoMapper orderDtoMapper = new OrderDtoMapper();
	private final OrderUniResponder orderUniResponder = new OrderUniResponder(orderDtoMapper);
	private final OrderMultiResponder orderMultiResponder = new OrderMultiResponder(orderDtoMapper);
	
	@Inject
	OrderService orderService;
	
	@POST
	public Uni<OrderDto> create(Orders orders){
		Uni<Orders> created = orderService.create(orders);
		return orderUniResponder.respond(created);
	}
	
	@GET
	@Path("/id/{id}")
	public Uni<OrderDto> fetchById(@RestPath Long id){
		Uni<Orders> orders = orderService.getById(id);
		return orderUniResponder.respond(orders);		
		
	}
	
	@GET
	public Multi<OrderDto> fetchAll(){
		Multi<Orders> orders = orderService.getAll(); 
		return orderMultiResponder.respond(orders);
	}
	
	@GET
	@Path("/status/{status}")
	public Multi<OrderDto> fetchByStatus(@RestPath Status status){
		Multi<Orders> orders = orderService.getByStatus(status);
		return orderMultiResponder.respond(orders);
	}
	
	@PUT
	@Path("/{id}/{status}")
	public Uni<Orders> update(@RestPath Long id, @RestPath Status status){
		return orderService.updateStatus(id, status);
	}
	
	@DELETE
	@Path("/{id}")
	public Uni<Response> deleteById(@RestPath Long id){
		try {
			return orderService.delete(id).map(deleted ->  deleted 
					? Response.status(Response.Status.NO_CONTENT).build()
				    : Response.status(Response.Status.NOT_FOUND).build());
			
		} catch (Exception e) {
			e.printStackTrace();
		    return Uni.createFrom().item(Response.status(Response.Status.BAD_REQUEST).build());
		}	
		}
}
