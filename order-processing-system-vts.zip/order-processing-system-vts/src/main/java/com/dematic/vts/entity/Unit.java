package com.dematic.vts.entity;

public enum Unit {

	kg,
	gm
	
}
