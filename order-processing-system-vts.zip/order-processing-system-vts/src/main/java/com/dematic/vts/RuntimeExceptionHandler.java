package com.dematic.vts;

import java.time.LocalDateTime;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class RuntimeExceptionHandler implements ExceptionMapper<RuntimeException>{

	private final Logger log = LoggerFactory.getLogger(RuntimeExceptionHandler.class);
	@Override
	public Response toResponse(RuntimeException e) {
		log.error(e.getMessage(),e);
		
		ErrorData errorData = new ErrorData();
		
		errorData.setStatus(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
		errorData.setMessage(e.getMessage());
		errorData.setTimeStamp(LocalDateTime.now());
		
		return Response.status(errorData.getStatus()).entity(errorData).build();
	}

}
