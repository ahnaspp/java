package com.dematic.vts.entity;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import io.quarkus.hibernate.reactive.panache.PanacheEntity;

@Entity
public class Orders extends PanacheEntity{
	
	@Column(nullable = false)
	@Enumerated(EnumType.STRING)
	private Status orderStatus;
	
	@Column(nullable = false)
	private LocalDate createdDate;
	
	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "orderlines")
	private List<Products> orderLines;

	public Status getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(Status orderStatus) {
		this.orderStatus = orderStatus;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public List<Products> getOrderLines() {
		return orderLines;
	}

	public void setOrderLines(List<Products> orderLines) {
		this.orderLines = orderLines;
	}
	
	

}
