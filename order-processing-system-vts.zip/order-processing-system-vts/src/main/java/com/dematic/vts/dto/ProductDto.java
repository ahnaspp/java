package com.dematic.vts.dto;

import com.dematic.vts.entity.Status;
import com.dematic.vts.entity.Unit;

import lombok.Data;

@Data
public class ProductDto {
	
	private Long id;
	
	private String productCode;
	
	private Double quantity;
	
	private Unit quantityUnit;
	
	private Status productStatus;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public Unit getQuantityUnit() {
		return quantityUnit;
	}

	public void setQuantityUnit(Unit quantityUnit) {
		this.quantityUnit = quantityUnit;
	}

	public Status getProductStatus() {
		return productStatus;
	}

	public void setProductStatus(Status productStatus) {
		this.productStatus = productStatus;
	}

	
}
