package com.dematic.vts;

import java.time.LocalDateTime;

import javax.ws.rs.core.Response;

public class BaseHttpException extends RuntimeException{
	
	private final Integer status;
	
	private final String message;
	
	private final LocalDateTime timeStamp;

	
	public BaseHttpException(Response.Status status, String message) {
		this.status = status.getStatusCode();
		this.message = message;
		this.timeStamp = LocalDateTime.now();
	}

	public Integer getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}
	
	
}
