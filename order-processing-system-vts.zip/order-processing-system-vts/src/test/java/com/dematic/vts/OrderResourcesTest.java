package com.dematic.vts;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import com.dematic.vts.dto.OrderDto;
import com.dematic.vts.dto.ProductDto;
import com.dematic.vts.entity.Orders;
import com.dematic.vts.entity.Products;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.is;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;

@QuarkusTest
public class OrderResourcesTest {

	 
	
//	  @Test 
//	  public void testFetchAll() { 
//		  given() 
//		  .when().get("/orders") 
//		  .then()
//		  .body("id", hasItems(100,101))
//		  .body("createdDate", hasItems("2020-12-03","2020-10-04")) 
//		  .body("status", hasItems("PENDING","COMPLETED"))
//	  .statusCode(Response.Status.OK.getStatusCode()); }
	  
	  @Test 
	  public void testFetchById() { 
		  given() 
		  .when()
		  .get("/orders/id/{id}","100") 
		  .then() 
		  .body("id", equalTo(100))
		  .body("orderStatus", equalTo("PENDING")) 
		  .body("createdDate", equalTo("2020-12-03")) 
		  .statusCode(Response.Status.OK.getStatusCode());
		  }
	  
	 /* @Test public void testFetchByIdFail() { given() .when() .get("/orders/id/{id}","103")
	 * .then() .statusCode(Response.Status.NOT_FOUND.getStatusCode()); }
	 * 
	 * @Test public void testFetchByStatus() { given() .when()
	 * .get("/orders/status/{status}","COMPLETED") .then() .body("id", equalTo(1))
	 * .body("orderStatus", equalTo("COMPLETED")) .body("createdDate",
	 * equalTo("2022-05-06")) .statusCode(Response.Status.OK.getStatusCode()); }
	 * 
	 * @Test public void testFetchByStatusFail() { given() .when()
	 * .get("/orders/status/{status}","PENDING") .then()
	 * .statusCode(Response.Status.NOT_FOUND.getStatusCode()); }
	 * 
	 * @Test public void testUpdate() { given() .when() .put("/orders/1/PENDING")
	 * .then() .body("id", equalTo(1)) .body("orderStatus", equalTo("PENDING"))
	 * .body("createdDate", equalTo("2022-05-06"))
	 * .statusCode(Response.Status.OK.getStatusCode()); }
	 * 
	 * @Test public void testUpdateFail() { given() .when()
	 * .put("/orders/3/PENDING") .then()
	 * .statusCode(Response.Status.NOT_FOUND.getStatusCode()); }
	 * 
	 * @Test public void testDeleteById() { given() .when()
	 * .delete("/orders/{id}","1") .then()
	 * .statusCode(Response.Status.NO_CONTENT.getStatusCode()); }
	 * 
	 * @Test public void testDeleteByIdFail() { given() .when()
	 * .delete("/orders/{id}","3") .then()
	 * .statusCode(Response.Status.NOT_FOUND.getStatusCode()); }
	 */
    
}