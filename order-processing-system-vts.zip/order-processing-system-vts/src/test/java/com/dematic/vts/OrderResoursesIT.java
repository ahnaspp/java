package com.dematic.vts;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class OrderResoursesIT extends OrderResourcesTest {
    // Execute the same tests but in packaged mode.
}
